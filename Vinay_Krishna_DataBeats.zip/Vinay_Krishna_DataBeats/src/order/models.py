# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from products.models import Products
from django.core.validators import (MaxValueValidator, MinValueValidator,
                                    RegexValidator)
from userprofile.models import User
# from ..search import index
# from satchless.item import ItemLine, ItemSet
# Create your models here.
class Order(models.Model):
    retailer = models.ForeignKey('userprofile.user', related_name='retailer_user', on_delete=models.CASCADE)
    created_on = models.DateTimeField(auto_now_add=True, null = True)
    total = models.DecimalField(decimal_places=2, max_digits=12,null=True)
    payment_type = models.TextField(null=True)


class OrderItems(models.Model):
    order = models.ForeignKey('Order', related_name='orders', on_delete=models.CASCADE)
    item_name = models.CharField(max_length=256, blank=True, null=True)
    bill_total = models.DecimalField(decimal_places=2, max_digits=12,null=True)
    quantity =  models.IntegerField(validators=[MinValueValidator(0), MaxValueValidator(1000)], default=0)

