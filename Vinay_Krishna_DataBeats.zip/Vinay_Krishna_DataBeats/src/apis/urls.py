from django.conf.urls import url
from django.contrib.auth import views as django_views

from . import views
urlpatterns = [
    url(r'^signup/v1.0$', views.signup, name='account_signup'),
    url(r'^login/', views.login,name ='login'),
    url(r'^add_purchase_items/',views.add_purchase_items, name='add_purchase_items'),
    url(r'add_products/', views.add_products, name='add_products'),
    url(r'generate_otp/', views.generate_otp, name='generate_otp'),
    url(r'validate_otp/', views.validate_otp, name='validate_otp'),
    url(r'get_items/', views.get_items, name='get_items'),
]