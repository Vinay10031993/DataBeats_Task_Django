# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from random import randint
from django.http import JsonResponse
import json
from django.db import transaction
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from userprofile.models import User, UserToken, OtpVerification
# Create your views here.
from cryptography.fernet import Fernet
from order.models import Order, OrderItems
from products.models import Products
from decimal import Decimal
@csrf_exempt
def login(request):
    if request.method == 'POST':
        validate_login(request)


def validate_login(request):
    if not request.POST.get('phone') or request.POST.get('phone') == '':    
        if not request.POST.get('email') or request.POST.get('email') == '':
            return False
    if not request.POST.get('password') or request.POST.get('password') == '':
        return False
    return True



def validate_input(request):
    print request.POST.get('phone')
    print request.POST.get('country')
    if not request.POST.get('phone') or request.POST.get('country') == '':
        return False
    else:
        return True


@csrf_exempt
def signup(request):
    if request.method == "POST":
        with transaction.atomic():
            if not validate_input(request):
                return respondWithError(200, "Found missing inputs, Please fill all the required details")
                
            isuser = User.objects.filter(phone=request.POST.get('phone'))
            if isuser.exists():
                return respondWithError(200, 'User Already exists')
            password = request.POST.get('password')
            key = Fernet.generate_key()
            cipher_suite = Fernet(key)
            encoded_text = cipher_suite.encrypt(str(password))

            user = User.objects.create(
                    email = request.POST.get('email'),
                    phone = request.POST.get('phone'),
                    user_name = request.POST.get('name'),
                    is_active = True,
                    country = request.POST.get('country'),
                    password = encoded_text,
                    key=key
                )
            token = UserToken.objects.create(user = user, access_token = encoded_text)
            print respondWithSuccess(200, 'User created successfully', token.access_token)
            return respondWithSuccess(200, 'User created successfully', token.access_token)
    else:
        return respondWithError(404, 'Wow! You found something that we thought did not exist. Please check the request type')

@csrf_exempt
def login(request):
    if request.method == "POST":
        data = json.loads(request.body)
        phone = data['phone']
        password = data['password']
        if not phone or not password:
            return respondWithError(200,"Fields cant be empty")
        phone = phone
        password = password

        sis = User.objects.filter(phone=phone)
        if sis.exists():
            usr = sis.first()
            decrypt = usr.decrypt_password()
            print str(decrypt) , str(password), str(decrypt) == str(password)
            if str(decrypt) == str(password):

                usrtok = UserToken.objects.filter(id = usr.id)
                acctok = ''
                if usrtok.exists():
                    acctok = usrtok.first().access_token
                else:
                    key = Fernet.generate_key()
                    cipher_suite = Fernet(str(sis.first().key))
                    acctok = cipher_suite.encrypt(str(password))

                return respondWithItem(200, usr, {
                    "user_id": usr.id,
                    "token": acctok,
                    "country": usr.country,
                    "email": usr.email
                }, acctok)
            else:
                return respondWithError(200,"Credentials doesnt match, Please check again.")
        else:
            return respondWithError(200,"User not found")
    else:
        return respondWithError(404, 'Wow! You found something that we thought did not exist. Please check the request type')












def random_with_N_digits(n):
    range_start = 10**(n-1)
    range_end = (10**n)-1
    return randint(range_start, range_end)

@csrf_exempt
def generate_otp(request):
    if request.method == "POST":
        print request.body
        data = json.loads(request.body)
        print data
        user = User.objects.filter(phone=data["phone"])
        if user.exists():
            num = random_with_N_digits(6)
            otp = OtpVerification.objects.get_or_create(user=user.first(),otp=num)
            return respondWithItem(200,'', {"otp": num})
        else:
            return respondWithError(200,"User not Found.")
    else:
        return respondWithError(404, 'Wow! You found something that we thought did not exist. Please check the request type')


@csrf_exempt
def validate_otp(request):
    if request.method == "POST":
        data = json.loads(request.body)
        print data
        user = User.objects.filter(phone=data["phone"])
        if user.exists():
            num = random_with_N_digits(6)
            otp = OtpVerification.objects.filter(user=user.first())
            if otp.exists():
                if str(otp.first().otp) == str(data['otp']):
                    pos = otp.first()
                    pos.delete()
                    return respondWithSuccess(200, "OTP Verification Successful")
                else:
                    return respondWithError(200,"You have entered wrong OTP")
            else:
                return respondWithError(200,"OTP is not generated.")
        else:
            return respondWithError(200,"User not Found.")
    else:
        return respondWithError(404, 'Wow! You found something that we thought did not exist. Please check the request type')


@csrf_exempt
def add_purchase_items(request):
    if request.method == 'PUT':
        data = json.loads(request.body)
        user = User.objects.filter(phone=data['user_phone'])
        if user.exists():
            with transaction.atomic():
                user = user.first()
                ords = Order.objects.create(retailer=user,payment_type=data['payment_type'],total=Decimal(data['billed_total']))
                items = data['items']
                for itms in items:
                    odritems = OrderItems.objects.create(order=ords,bill_total=itms['total'], item_name=itms['product_name'],quantity=itms['quantity'])

            return respondWithSuccess(200,"Details Updated successfully")
        else:
            return respondWithError(200, "User does not exists.")
    else:
        return respondWithError(404, 'Wow! You found something that we thought did not exist. Please check the request type')


@csrf_exempt
def add_products(request):
    if request.method == "POST":
        with transaction.atomic():
            data = json.loads(request.body)
            data=data['items']
            for itms in data:
                Products.objects.create(product_name=itms['product_name'],product_type=itms['product_type'],ptr=itms['ptr'],expiry=itms['expiry'])
            return respondWithSuccess(200,"Details Updated successfully")
    else:
        return respondWithError(404, 'Wow! You found something that we thought did not exist. Please check the request type')


@csrf_exempt
def get_items(request):
    if request.method == "GET":
        product = Products.objects.all()
        print request.META['HTTP_ACCESS_TOKEN']
        if not UserToken.objects.filter(access_token=request.META['HTTP_ACCESS_TOKEN']).exists():
            return respondWithError(404, 'Access token does not exists or expired. Please Login again to create a new access token')

        dics = []
        for itms in product:
            dics.append({"Product_Name": itms.product_name,"Product_Type": itms.product_type,"Price": itms.ptr,"Expiry": itms.expiry})
        return respondWithItem(200, '', dics)
    else:
        return respondWithError(404, 'Wow! You found something that we thought did not exist. Please check the request type')
def respondWithError(statusCode, message, access_token=None, data=None, is_auth= True):
    response = {}
    if data is not None:
        response['data'] = []
    else:
        response['data'] = {}
    
    response['notification'] = {}
    response['notification']['hint'] = "Error"
    response['notification']['message'] = message
    response['notification']['code'] = statusCode
    response['notification']['type'] = "Failed"
    response['notification']['is_auth'] = is_auth
    
    response = JsonResponse(response, content_type='application/json', status=statusCode)
    response['accessToken'] = access_token
    return response


def respondWithItem(statusCode, data, transformer, access_token=None, is_auth= True):
    response = {}
    response['data'] = transformer
    response['notification'] = {}    
    response['notification']['hint'] = "Response Sent"
    response['notification']['message'] = "Success"
    response['notification']['code'] = "200"
    response['notification']['type'] = "Success"
    response['notification']['is_auth'] = is_auth
    
    response = JsonResponse(response, content_type='application/json', status=statusCode)
    response['accessToken'] = access_token
    return response

def respondWithSuccess(statusCode, message, access_token=None, is_auth= True):
    response = {}
    response['data'] = {}
    
    response['notification'] = {}
    response['notification']['hint'] = "Success"
    response['notification']['message'] = message
    response['notification']['code'] = statusCode
    response['notification']['token'] = access_token
    response['notification']['type'] = "Success"
    response['notification']['is_auth'] = is_auth
    
    response =  JsonResponse(response, content_type='application/json', status=statusCode)
    response['accessToken'] = access_token
    return response


        
def transform(data):
	return {
		'id': data['id'],
		'email': data['email'],
		'isRetailer': data['is_retailer'],
		'isValidated': data['is_validated'],
		'name': data['name'],
		'storeName': data['store_name'],
		'storelicenseNumber': data['store_license_number'],
		'pharmacistlicenseNumber': data['pharmacist_license_number'],
		'phone': data['phone'],
		'addresses': data['addresses'],
		'savedValue': data.get('saved_value'),
		'version': '1.0'
	}