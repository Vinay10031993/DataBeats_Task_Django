# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.contrib.auth.models import (AbstractBaseUser, BaseUserManager,
                                        PermissionsMixin)
from datetime import datetime, timedelta
from django.db import models
from cryptography.fernet import Fernet


# Create your models here.
class User(models.Model):
    email = models.CharField(null=True, max_length=50)
    is_retailer = models.BooleanField(default=False)
    # is_distributor = models.BooleanField(default=False)
    user_name = models.CharField(max_length=126,null=True)
    is_active = models.BooleanField(default=True)
    phone = models.CharField(max_length=15,null = True, unique=True, blank=True)
    country = models.CharField(max_length=15,null = True,blank=True)
    password = models.TextField(null=True)
    key = models.TextField(null=True)

    def decrypt_password(self):
        key = str(self.key)
        print key,"=-------"
        print key
        cipher_suite = Fernet(key)
        decoded_text = cipher_suite.decrypt(str(self.password))
        return decoded_text




# class UserManager(BaseUserManager):

#     def create_user(self, phone, password=None, is_staff=True,
#                     is_active=True, username='', **extra_fields):
#         'Creates a User with the given username, email and password'
#         phone = self.format_phone(phone)
#         user = self.model(phone=phone, is_active=is_active,
#                           is_staff=is_staff, **extra_fields)
#         if password:
#             user.set_password(password)
#         user.save()
#         return user

class UserToken(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    access_token = models.CharField("user's login unique access token", max_length=255, unique=True)
    last_queried_on = models.DateTimeField(null=True)
    expires_at = models.DateTimeField(default=datetime.now()+timedelta(days=5))
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


class OtpVerification(models.Model):
    user = models.ForeignKey(User,related_name = "optforuser")
    otp = models.CharField(max_length=100, null=True)


